import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.openimaj.image.DisplayUtilities;
import org.openimaj.image.FImage;
import org.openimaj.image.ImageUtilities;
import org.openimaj.image.processing.face.detection.DetectedFace;
import org.openimaj.image.processing.face.detection.HaarCascadeDetector;

public class FaceDe {
	 static List<DetectedFace> faces = null;
	 static List<DetectedFace> faces1 = null;
	 private static BufferedImage img= null;
	 private static BufferedImage img1= null;
	 static final HaarCascadeDetector detector = new HaarCascadeDetector();
	 static final HaarCascadeDetector detector1 = new HaarCascadeDetector();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedImage imgA = null; 
		BufferedImage imgB = null; 

		try
		{ 
			File fileA = new File("C:\\Users\\kadreddy\\Downloads\\testing\\a.jpg"); 
			File fileB = new File("C:\\Users\\kadreddy\\Downloads\\testing\\b.jpg"); 
			imgA = ImageIO.read(fileA); 
			imgB = ImageIO.read(fileB); 
//			img=imgA;
//			faces = detector.detectFaces(ImageUtilities.createFImage(img));
//			Iterator<DetectedFace> dfi = faces.iterator();
//			while (dfi.hasNext()) {
//				DetectedFace face = dfi.next();
//				FImage image1 = face.getFacePatch();
//				imgA= ImageUtilities.createBufferedImage(image1);
//			}
//			img1=imgB;
//			faces1 = detector1.detectFaces(ImageUtilities.createFImage(img1));
//			Iterator<DetectedFace> dfi1 = faces1.iterator();
//			while (dfi1.hasNext()) {
//				DetectedFace face1 = dfi1.next();
//				FImage image12 = face1.getFacePatch();
//				imgB= ImageUtilities.createBufferedImage(image12);
//			}
			imgA=resizeImage(imgA, 100, 100);
			imgB=resizeImage(imgB, 100, 100);
			//DisplayUtilities.display(imgA);
			
			
		} 
		catch (IOException e) 
		{ 
			System.out.println(e); 
		} 
		int width1 = imgA.getWidth(); 
		int height1 = imgA.getHeight();  
		long difference = 0; 
			for (int y = 0; y < height1; y++) 
			{ 
				for (int x = 0; x < width1; x++) 
				{ 
					int rgbA = imgA.getRGB(x, y); 
					int rgbB = imgB.getRGB(x, y); 
					int redA = (rgbA >> 16) & 0xff; 
					int greenA = (rgbA >> 8) & 0xff; 
					int blueA = (rgbA) & 0xff; 
					int redB = (rgbB >> 16) & 0xff; 
					int greenB = (rgbB >> 8) & 0xff; 
					int blueB = (rgbB) & 0xff; 
					difference += Math.abs(redA - redB); 
					difference += Math.abs(greenA - greenB); 
					difference += Math.abs(blueA - blueB); 
				} 
			} 
			double total_pixels = width1 * height1 * 3; 
			double avg_different_pixels = difference / total_pixels; 
			double percentage = (avg_different_pixels / 255) * 100;   
			System.out.println("Difference Percentage-->" + compareImage(imgA,imgB));

	}
	
	public static BufferedImage resizeImage(final Image image, int width, int height) {
        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setComposite(AlphaComposite.Src);
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }
	
	
	
	public static float compareImage(BufferedImage biA, BufferedImage biB) {

	    float percentage = 0;
	    try {
	        // take buffer data from both image files //
	       // BufferedImage biA = ImageIO.read(fileA);
	        DataBuffer dbA = biA.getData().getDataBuffer();
	        int sizeA = dbA.getSize();
	        //BufferedImage biB = ImageIO.read(fileB);
	        DataBuffer dbB = biB.getData().getDataBuffer();
	        int sizeB = dbB.getSize();
	        int count = 0;
	        // compare data-buffer objects //
	        if (sizeA == sizeB) {

	            for (int i = 0; i < sizeA; i++) {

	                if (dbA.getElem(i) == dbB.getElem(i)) {
	                    count = count + 1;
	                }

	            }
	            percentage = (count * 100) / sizeA;
	        } else {
	            System.out.println("Both the images are not of same size");
	        }

	    } catch (Exception e) {
	        System.out.println("Failed to compare image files ...");
	    }
	    return percentage;
	}
	
	
	
	
	

}
