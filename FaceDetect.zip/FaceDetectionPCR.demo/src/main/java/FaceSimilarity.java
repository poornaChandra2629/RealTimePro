import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.imageio.ImageIO;

import org.openimaj.feature.FloatFV;
import org.openimaj.feature.FloatFVComparison;
import org.openimaj.image.DisplayUtilities;
//import org.openimaj.image.DisplayUtilities;
import org.openimaj.image.FImage;
import org.openimaj.image.ImageUtilities;
import org.openimaj.image.processing.face.detection.HaarCascadeDetector;
import org.openimaj.image.processing.face.detection.keypoints.FKEFaceDetector;
import org.openimaj.image.processing.face.detection.keypoints.KEDetectedFace;
import org.openimaj.image.processing.face.feature.FacePatchFeature;
import org.openimaj.image.processing.face.feature.FacePatchFeature.Extractor;
import org.openimaj.image.processing.face.feature.comparison.FaceFVComparator;
import org.openimaj.image.processing.face.similarity.FaceSimilarityEngine;
public class FaceSimilarity {
	public static void main(String[] args) throws IOException, InterruptedException {
		int flag=2;
		while(flag!=0)
		{
		FImage image1 = ImageUtilities.readF(new File("C:\\Users\\kadreddy\\Downloads\\testing\\b.jpg"));
		 FImage image2 = ImageUtilities.readF(new File("C:\\Users\\kadreddy\\Downloads\\testing\\a.jpg"));
		if(flag == 1)
		{
			FImage timag=image1;
			image1=image2;
			image2=timag;
			
		}
		final HaarCascadeDetector detector = HaarCascadeDetector.BuiltInCascade.frontalface_alt2.load();
		final FKEFaceDetector kedetector = new FKEFaceDetector(detector);
		final Extractor extractor = new FacePatchFeature.Extractor();
		final FaceFVComparator<FacePatchFeature, FloatFV> comparator =
				new FaceFVComparator<FacePatchFeature, FloatFV>(FloatFVComparison.EUCLIDEAN);
		final FaceSimilarityEngine<KEDetectedFace, FacePatchFeature, FImage> engine =
				new FaceSimilarityEngine<KEDetectedFace, FacePatchFeature, FImage>(kedetector, extractor, comparator);
		engine.setQuery(image1, "image1");
		engine.setTest(image2, "image2");
		engine.performTest();
		if(engine.getSimilarityDictionary().size() !=0)
		{
		for (final Entry<String, Map<String, Double>> e : engine.getSimilarityDictionary().entrySet()) {
			double bestScore = Double.MAX_VALUE;
			String best = null;
			for (final Entry<String, Double> matches : e.getValue().entrySet()) {
				if (matches.getValue() < bestScore) {
					bestScore = matches.getValue();
					best = matches.getKey();
				}
			}
			FImage img = new FImage(image1.width,image1.height);
			img.drawImage(image1, 0, 0);
			img.drawShape(engine.getBoundingBoxes().get(e.getKey()), 1F);
			//System.out.print((int)engine.getBoundingBoxes().get(e.getKey()).height);
			BufferedImage imageres=ImageUtilities.createBufferedImage(img);
			imageres=imageres.getSubimage((int)engine.getBoundingBoxes().get(e.getKey()).x, (int)engine.getBoundingBoxes().get(e.getKey()).y,(int) engine.getBoundingBoxes().get(e.getKey()).width, (int)engine.getBoundingBoxes().get(e.getKey()).height);
			String path="";
			if(flag ==1)
				path="C:\\\\Users\\\\kadreddy\\\\Downloads\\\\testing\\\\poorna.jpg";
			else
				path="C:\\\\Users\\\\kadreddy\\\\Downloads\\\\testing\\\\123.jpg";
			File pathFile = new File(path);
			ImageIO.write(imageres,"jpg", pathFile);
		}
		}
		else
		System.out.println("Error While Filtering");
		flag--;
		}
	}
}