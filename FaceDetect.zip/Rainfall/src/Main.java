import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.Timer;

public class Main extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;

	Raindrop raindrop;
	
	Graphics bufferGraphics;
	Image offscreen;
	
	public boolean isRunning = false;
	public Color purple = new Color(147, 0, 147);
	
	final int WIDTH = 400;
	final int HEIGHT = 300;
	
	private void Init(){
		raindrop = new Raindrop();
		
		setTitle("Purple Rain");
		setSize(WIDTH, HEIGHT);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBackground(Color.WHITE);
		
		offscreen = createImage(WIDTH, HEIGHT);
		bufferGraphics = offscreen.getGraphics();
	}
	
	private void start(){
		Timer timer = new Timer(5, this);
		timer.start();
		
		isRunning = true;
		
		while(isRunning == true){
			System.out.println(isRunning + ": " + raindrop.getDropWidth() + ": " + raindrop.getDropHeight()
					+ ": " + raindrop.getPosX() + ": " + raindrop.getPosY());
		}
	}
	
	public void update(){
		raindrop.move();
		checkCollision();
		repaint();
	}
	
	public void paint(Graphics g){
		bufferGraphics.clearRect(0, 0, WIDTH, HEIGHT);
		
		// Draws the rain
		bufferGraphics.setColor(purple);
		bufferGraphics.fillRect(raindrop.getPosX(), raindrop.getPosY(), raindrop.getDropWidth(), raindrop.getDropHeight());
		
		// Draw the offscreen image to the JFrame
		g.drawImage(offscreen, 0, 0, this);
		
		// Makes sure monitors are up to date before proceeding
		Toolkit.getDefaultToolkit().sync();
	}
	
	public void checkCollision(){
		if(raindrop.getPosY() == 300){
			raindrop.reset();
		}
	}

	public void actionPerformed(ActionEvent arg0) {
		raindrop.move();
		checkCollision();
		repaint();
	}

	public static void main(String[] args){
		Main main = new Main();
		
		main.Init();
		main.start();
	}
}
