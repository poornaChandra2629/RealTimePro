import java.util.Random;

public class Raindrop{
	private Random rand = new Random();
	
	private int xPos, yPos, dropWidth, dropHeight;
	
	public Raindrop(){
		setPos(xPos, yPos);
		setSize(dropWidth, dropHeight);
	}
	
	public void setPos(int xPos, int yPos){
		xPos = rand.nextInt(400)+1;
		this.xPos = xPos;
		yPos = rand.nextInt(10)+1;
		this.yPos = yPos;
	}
	
	public int getPosX(){
		return xPos;
	}
	
	public int getPosY(){
		return yPos;
	}
	
	public void setSize(int dropWidth, int dropHeight){
		dropWidth = rand.nextInt(2)+1;
		this.dropWidth = dropWidth;
		dropHeight = rand.nextInt(15)+1;
		this.dropHeight = dropHeight;
	}
	
	public int getDropWidth(){
		return dropWidth;
	}
	
	public int getDropHeight(){
		return dropHeight;
	}
	
	public void move(){
		yPos += 1;
	}
	
	public void reset(){
		setPos(xPos, yPos);
		setSize(dropWidth, dropHeight);
	}
}