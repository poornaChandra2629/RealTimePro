/* This applet is based on the Bell & Parr Rainfall applet

   With extensive modifications by SBJ:
   - April 2001: Collapsed into one class, avoiding MVC architecture (to fit the course structure)
   - March 1999: Removed questionable aspects of the original program design:
                 o poorly placed declarations, 
                 o poorly placed recomputation of totals,
                 o strange user interaction pattern 
                   (the user now types a number and clicks (level with) the required location;
                    mouse clicks too high or too low are ignored, and non-numeric input
                    causes a NumberFormatException)
                 It still really needs an x coordinate check so that clicks *must* be in the boxes,
                 and an elegant error response when non-numeric data is entered (needs exception
                 handling).
   - March 2003: Added code to clear text field after processing the input data
*/

import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class Rainfall extends Applet
                      implements MouseListener {

 
  private final int tableSize = 7;                                   // Number of entries in table (one per day of week)
  private int[] rain = new int[tableSize];                           // Array of integer daily rainfall amounts

  private int sum = 0;                                               // Keeps the weekly total of daily rainfalls

  private final int startX = 20;                                     // Constants for drawing the box layout
  private final int startY = 60;
  private final int boxHeight = 20;
  private final int boxWidth = 60;

  private TextField value;                                           // For entry of a new rainfall

  // Set up the rainfall table and GUI:
  public void init() {
  
    for (int day = 0; day < tableSize; day++)                        // Set rainfalls to zero
      rain[day] = 0;

    Label l = new Label("Enter number, then click component");
    add(l);
    value = new TextField(10);                                       // For entry of a new rainfall
    add(value);
    
    addMouseListener(this);                                          // To enable mouse click event handling

  } // init

  // Display the daily rainfalls and the weekly total
  public void paint(Graphics g) {
  
    displayTable(g);
    g.drawString("Total rainfall is " + sum, 100, 100);

  } // paint

  // Draw the rainfall table boxes, with values in
  // Note the strict use of the layout constants
  private void displayTable(Graphics g) {
  
    int y = startY;
    for (int day = 0; day < tableSize; day++) {                      // For days 0 to 6
      g.drawRect(startX, y, boxWidth, boxHeight);                    // Draw box
      g.drawString(Integer.toString(rain[day]), startX+5, y + boxHeight*3/4); // and place rainfall value in it
      y = y + boxHeight;                                             // Ready for next box down
    }
    
  } // displayTable

  // Respond to mouse click: send y coordinate of mouse click and decoded ("parsed")
  // integer from the text field to selectComponent. Clear the text field.
  public void mouseClicked(MouseEvent e) {
  
    // Note: Really need a try/catch here to protect elegantly against bad input
    int newValue = Integer.parseInt(value.getText());                // Fetch the text field contents and decode
    selectComponent(e.getY(), newValue);                             // Process coordinate and value
    value.setText("");                                               // Clear the text field
    repaint();
    
  } // mouseClicked

  // Given the y coordinate of a mouse click, and a new rainfall value,
  // calculate which table entry it belongs in, and put it there.
  // Note: the new value is simply ignored if the y coordinate does not correspond to a table entry
  private void selectComponent(int y, int newValue) {
  
    if (startY <= y && y <= startY+tableSize*boxHeight) {            // Check that the y coordinate corresponds to a valid table component
      int index = (y - startY)/boxHeight;                            // Calculate index of table entry
      rain[index] = newValue;                                        // Insert new rainfall
      addValues();                                                   // Best to recompute the totals here rather than in paint
    }
    
  } // selectComponent

  // Add up all the daily rainfalls, and store in global sum
  private void addValues() {
  
    sum = 0;
    for (int day = 0; day < rain.length; day++)
      sum = sum + rain[day];
      
  } // addValues
  
  // These other MouseListener event handlers must be here,
  // but are not required in this applet, so have empty bodies:
  
  public void mouseReleased(MouseEvent e) {}

  public void mousePressed(MouseEvent e) {}

  public void mouseEntered(MouseEvent e) {}

  public void mouseExited(MouseEvent e) {}
  
} // End of class Rainfall